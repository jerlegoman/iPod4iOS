//
//  DTBlockScrollerView.h
//  iPod
//
//  Created by Daniel Tull on 26.07.2009.
//  Copyright 2009 Daniel Tull. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface _FGYScroller : UIView
@property (nonatomic, assign) IBOutlet UITableView *tableView;
@end
