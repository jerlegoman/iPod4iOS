#import "_DCTPlaylist.h"

@interface DCTPlaylist : _DCTPlaylist {}
// Custom logic goes here.
@end
