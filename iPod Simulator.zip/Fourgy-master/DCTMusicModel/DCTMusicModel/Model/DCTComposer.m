#import "DCTComposer.h"

@implementation DCTComposer

// Custom logic goes here.

@end
