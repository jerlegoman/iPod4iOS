#import "DCTGenre.h"

@implementation DCTGenre

// Custom logic goes here.

@end
