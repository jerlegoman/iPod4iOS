#import "_DCTComposer.h"

@interface DCTComposer : _DCTComposer {}
// Custom logic goes here.
@end
