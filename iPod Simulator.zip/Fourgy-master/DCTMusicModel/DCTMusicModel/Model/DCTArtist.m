#import "DCTArtist.h"

@implementation DCTArtist

// Custom logic goes here.

@end
