#import "_DCTArtist.h"

@interface DCTArtist : _DCTArtist {}
// Custom logic goes here.
@end
