#import "_DCTGenre.h"

@interface DCTGenre : _DCTGenre {}
// Custom logic goes here.
@end
