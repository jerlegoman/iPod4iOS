#import "_DCTAlbum.h"

@interface DCTAlbum : _DCTAlbum {}
// Custom logic goes here.
@end
