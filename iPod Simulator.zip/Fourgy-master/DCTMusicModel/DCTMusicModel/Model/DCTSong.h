#import "_DCTSong.h"
#import <MediaPlayer/MediaPlayer.h>

@interface DCTSong : _DCTSong
- (MPMediaItem *)mediaItem;
@end
