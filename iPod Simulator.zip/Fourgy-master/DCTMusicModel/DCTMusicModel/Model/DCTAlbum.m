#import "DCTAlbum.h"

@implementation DCTAlbum

// Custom logic goes here.

@end
