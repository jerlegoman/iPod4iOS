//
//  AppDelegate.h
//  DCTMusicModelApp
//
//  Created by Daniel Tull on 19.07.2012.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
