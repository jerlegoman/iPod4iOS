//
//  DCTCoreDataStackTests.h
//  DCTCoreDataStackTests
//
//  Created by Daniel Tull on 14.06.2012.
//  Copyright (c) 2012 Daniel Tull. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DCTCoreDataStackTests : SenTestCase

@end
