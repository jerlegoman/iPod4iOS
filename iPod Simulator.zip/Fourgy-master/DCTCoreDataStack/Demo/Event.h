#import "_Event.h"

@interface Event : _Event {}
// Custom logic goes here.
@end
