#import "Event.h"

@implementation Event

// Custom logic goes here.

@end
